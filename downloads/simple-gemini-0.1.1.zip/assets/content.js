var d=Object.defineProperty;var u=(o,t,e)=>t in o?d(o,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):o[t]=e;var r=(o,t,e)=>u(o,typeof t!="symbol"?t+"":t,e);function c(o,t,e){const n=e.width>0?e.width:Math.min(360,t.innerWidth-24),s=t.scrollX+12,i=t.scrollX+t.innerWidth-n-12,l=o.centerX-n/2;return{left:h(l,s,Math.max(s,i)),top:Math.max(t.scrollY+12,o.bottom+10)}}function h(o,t,e){return Math.min(e,Math.max(t,o))}const p="simple-gemini-root",m=20,g={summaryEngine:"chrome_builtin_prompt",providerId:"gemini_api",modelId:"gemini-3.5-flash",preferLocal:!0,allowCloudFallback:!0,allowModelDownload:!0,enableExperimentalSummarizer:!1,defaultMode:"key_takeaways",defaultLength:"short",defaultFormat:"bullets",outputLanguage:"browser_ui",preserveTerminology:!0,includeKeywords:!1,includeActionItems:!1,includeRisks:!1,enableCache:!1,enableContextMenu:!0,enableSelectionButton:!0,selectionButtonStyle:"icon",privacyMode:"strict",websiteBlacklist:[],availableModelsByProvider:{}};class b{constructor(){r(this,"host");r(this,"shadow");r(this,"selectedText","");r(this,"selectionAnchor",null);this.host=document.createElement("div"),this.host.id=p,this.shadow=this.host.attachShadow({mode:"closed"}),this.shadow.append(f(),y(),x()),document.documentElement.append(this.host),this.bindEvents()}bindEvents(){document.addEventListener("mouseup",()=>window.setTimeout(()=>this.updateSelection(),0)),document.addEventListener("keyup",t=>{t.key==="Escape"?this.hideAll():this.updateSelection()}),window.addEventListener("scroll",()=>this.hideButton(),{passive:!0}),this.button.addEventListener("click",()=>{this.summarizeSelection(this.selectedText)}),this.copyButton.addEventListener("click",()=>{navigator.clipboard.writeText(this.summaryNode.textContent??"")}),document.addEventListener("pointerdown",t=>this.hideTooltipOnOutsidePointer(t)),chrome.runtime.onMessage.addListener(t=>{this.handleContentMessage(t)})}updateSelection(){const t=window.getSelection(),e=(t==null?void 0:t.toString().trim())??"";if(!this.tooltip.hidden){this.hideButton();return}if(!t||t.rangeCount===0||e.length<m){this.hideButton(),this.selectionAnchor=null;return}const n=t.getRangeAt(0).getBoundingClientRect();this.selectedText=e,this.showButton(n)}async summarizeSelection(t){if(!t.trim())return;this.hideButton();const e=await this.getSettings();if(!e.enableSelectionButton)return;const n={...w(t,"selection",e),pageContext:{url:location.href,title:document.title}};this.showLoading();const s=await a({type:"SUMMARY_REQUEST",payload:n});s.ok?this.showResult(s.result):this.showError(s.error)}handleContentMessage(t){t.type==="SUMMARY_LOADING"?this.showLoading():t.type==="SHOW_CONTEXT_MENU_SUMMARY"||t.type==="SUMMARY_SUCCESS"?this.showResult(t.payload):(t.type==="SHOW_CONTEXT_MENU_ERROR"||t.type==="SUMMARY_ERROR")&&this.showError(t.payload)}async getSettings(){try{return await a({type:"GET_SETTINGS"})}catch{return g}}async showButton(t){const e=await this.getSettings();if(!e.enableSelectionButton){this.hideButton();return}this.applyButtonStyle(e),this.selectionAnchor={centerX:t.left+window.scrollX+t.width/2,bottom:t.bottom+window.scrollY},this.button.hidden=!1;const n=e.selectionButtonStyle==="text"?96:26;this.button.style.left=`${Math.min(window.innerWidth-n-8,Math.max(8,t.left+window.scrollX))}px`,this.button.style.top=`${Math.max(8,t.bottom+window.scrollY+8)}px`}hideButton(){this.button.hidden=!0}showLoading(){this.hideButton(),this.tooltip.hidden=!1,this.tooltip.classList.remove("error"),this.titleNode.textContent="Simple Gemini",this.summaryNode.textContent="Summarizing...",this.copyButton.hidden=!0,this.positionTooltip()}showResult(t){this.hideButton(),this.tooltip.hidden=!1,this.tooltip.classList.remove("error"),this.titleNode.textContent=t.engineLabel??"Simple Gemini",this.summaryNode.textContent=t.summary,this.copyButton.hidden=!1,this.positionTooltip()}showError(t){this.hideButton(),this.tooltip.hidden=!1,this.tooltip.classList.add("error"),this.titleNode.textContent="Unable to summarize",this.summaryNode.textContent=t.message,this.copyButton.hidden=!0,this.positionTooltip()}hideAll(){this.hideButton(),this.tooltip.hidden=!0,this.selectionAnchor=null}hideTooltipOnOutsidePointer(t){this.tooltip.hidden||t.composedPath().includes(this.host)||this.hideAll()}applyButtonStyle(t){const e=t.selectionButtonStyle==="text"?"text":"icon";if(this.button.dataset.style=e,this.button.setAttribute("aria-label","Summarize selected text"),this.button.title="Summarize selected text",e==="text"){this.button.textContent="Summarize";return}const n=document.createElement("img");n.className="sg-button-icon",n.alt="",n.src=chrome.runtime.getURL("assets/gemini.png"),this.button.replaceChildren(n)}positionTooltip(){const t=this.selectionAnchor??{centerX:window.scrollX+window.innerWidth/2,bottom:window.scrollY+24},e=this.tooltip.getBoundingClientRect(),n=c(t,{scrollX:window.scrollX,scrollY:window.scrollY,innerWidth:window.innerWidth},{width:e.width});this.tooltip.style.top=`${n.top}px`,this.tooltip.style.left=`${n.left}px`}get button(){return this.shadow.querySelector(".sg-summary-button")}get tooltip(){return this.shadow.querySelector(".sg-tooltip")}get titleNode(){return this.shadow.querySelector(".sg-title")}get summaryNode(){return this.shadow.querySelector(".sg-summary")}get copyButton(){return this.shadow.querySelector(".sg-copy")}}function y(){const o=document.createElement("button");return o.className="sg-summary-button",o.type="button",o.dataset.style="icon",o.setAttribute("aria-label","Summarize selected text"),o.hidden=!0,o}function x(){const o=document.createElement("section");o.className="sg-tooltip",o.hidden=!0;const t=document.createElement("div");t.className="sg-header";const e=document.createElement("strong");e.className="sg-title",e.textContent="Simple Gemini";const n=document.createElement("p");n.className="sg-summary";const s=document.createElement("div");s.className="sg-summary-body";const i=document.createElement("button");return i.className="sg-copy",i.type="button",i.textContent="Copy",t.append(e,i),s.append(n),o.append(t,s),o}function f(){const o=document.createElement("style");return o.textContent=`
    :host {
      --sg-accent: #5595ff;
      --sg-button-bg: #ffffff;
      --sg-button-border: rgba(0, 0, 0, 0.18);
      --sg-button-shadow: rgba(0, 0, 0, 0.2);
      --sg-text: #172026;
      --sg-text-strong: #0c0c0d;
      --sg-panel: #ffffff;
      --sg-panel-border: #c8d0d6;
      --sg-panel-shadow: rgba(18, 31, 40, 0.18);
      --sg-control-bg: #e7ecef;
      --sg-error-border: #d49a9a;
      color-scheme: light dark;
    }
    @media (prefers-color-scheme: dark) {
      :host {
        --sg-button-bg: #202124;
        --sg-button-border: rgba(255, 255, 255, 0.24);
        --sg-button-shadow: rgba(0, 0, 0, 0.42);
        --sg-text: #e8eaed;
        --sg-text-strong: #f1f3f4;
        --sg-panel: #151617;
        --sg-panel-border: #4b4f52;
        --sg-panel-shadow: rgba(0, 0, 0, 0.5);
        --sg-control-bg: #2f3336;
        --sg-error-border: #d07a7a;
      }
    }
    .sg-summary-button {
      align-items: center;
      background: var(--sg-button-bg);
      border: 1px solid var(--sg-button-border);
      border-radius: 3px;
      box-shadow: 0 1px 4px var(--sg-button-shadow);
      box-sizing: border-box;
      color: var(--sg-text-strong);
      cursor: pointer;
      display: inline-flex;
      font: 600 13px "Segoe UI", system-ui, sans-serif;
      height: 24px;
      justify-content: center;
      padding: 2px;
      position: absolute;
      transition: border-color 100ms ease, box-shadow 100ms ease, background 100ms ease;
      width: 24px;
      z-index: 2147483647;
    }
    .sg-summary-button:hover,
    .sg-summary-button:focus {
      border-color: var(--sg-accent);
      box-shadow: 0 1px 6px rgba(85, 149, 255, 0.35);
      outline: none;
    }
    .sg-summary-button[data-style="text"] {
      background: #176b87;
      border: 0;
      border-radius: 6px;
      color: #fff;
      height: auto;
      padding: 7px 10px;
      width: auto;
    }
    .sg-button-icon {
      display: block;
      height: 18px;
      object-fit: contain;
      width: 18px;
    }
    .sg-tooltip {
      background: var(--sg-panel);
      border: 1px solid var(--sg-panel-border);
      border-radius: 8px;
      box-shadow: 0 10px 28px var(--sg-panel-shadow);
      box-sizing: border-box;
      color: var(--sg-text);
      display: grid;
      font: 14px system-ui, sans-serif;
      gap: 10px;
      max-width: 360px;
      padding: 12px;
      position: absolute;
      white-space: normal;
      width: min(360px, calc(100vw - 24px));
      z-index: 2147483647;
    }
    .sg-tooltip[hidden],
    .sg-summary-button[hidden] {
      display: none;
    }
    .sg-header {
      align-items: start;
      display: flex;
      gap: 8px;
      justify-content: space-between;
    }
    .sg-summary-body {
      display: block;
    }
    .sg-summary {
      margin: 0;
      white-space: pre-wrap;
    }
    .sg-title {
      font-size: 13px;
      line-height: 1.3;
    }
    .sg-copy {
      background: var(--sg-control-bg);
      border: 0;
      border-radius: 6px;
      color: var(--sg-text);
      cursor: pointer;
      flex: 0 0 auto;
      font: 600 13px system-ui, sans-serif;
      padding: 5px 8px;
    }
    .sg-tooltip.error {
      border-color: var(--sg-error-border);
    }
  `,o}function a(o){return chrome.runtime.sendMessage(o)}function w(o,t,e){return{requestId:crypto.randomUUID(),text:o,sourceLanguage:"auto",outputLanguage:e.outputLanguage,providerId:e.providerId,modelId:e.modelId,mode:e.defaultMode,length:e.defaultLength,format:e.defaultFormat,preserveTerminology:e.preserveTerminology,includeKeywords:e.includeKeywords,includeActionItems:e.includeActionItems,includeRisks:e.includeRisks,surface:t,privacyMode:e.privacyMode}}new b;
